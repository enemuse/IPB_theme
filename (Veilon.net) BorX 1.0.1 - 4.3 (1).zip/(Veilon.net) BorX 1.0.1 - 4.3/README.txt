﻿This skin is created by a team Studio Veilon

--- VERSION RELEASES ---
The version of the release indicated in the archive name with style and on the market invisionpower.com

--- DESCRIPTION ---
This skin is the official skin for the IPS Community Suite 4.2

--- LINKS ---
Current version of style You can download marketplace or in our store (in development)

--- TUTORIALS AND MANUALS ---
All the instructions and manuals You can find on our site veilon.net

--- AUTHORS ---
https://invisioncommunity.com/profile/554525-veilon/

The authors of the original skins are Denis Melnikov (WEB Programmer/Designer) & Michael Christagin (Designer)

--- DONATE ---
You can always help us by sending any amount to one of these accounts
PayPal:  donate@veilon.net | 
WebMoney: R194328279935 Z203139468139 E798668110512 U156493453579 
Yandex Money: 410011209649405

--- COPYRIGHT ---
You can remove the copyright before doing this by buying a plugin https://gum.co/veiloncopyrightremoval

===== Pay removing copyrights is available on this link  =====

https://gum.co/veiloncopyrightremoval


--- YOUR RIGHTS ---
Your rights are specified in the file LICENSE

--- REVIEWS ON THE MARKETPLACE ---
If You liked our work then You can leave your opinion about it on the page style. This will help us in the development of our project and the quality of our themes. Thank`s ! ¯\_(ツ)_/¯ 

Regard`s Veilon Team